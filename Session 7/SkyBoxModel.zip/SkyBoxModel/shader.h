#ifndef SHADER_H
#define SHADER_H

#include <GL/glew.h>
#include <GL/freeglut.h>

int setShader(const char* shaderType, const char* shaderFile);

void shaderCompileTest(GLuint shader);

char* readTextFile(const char* aTextFile);

#endif