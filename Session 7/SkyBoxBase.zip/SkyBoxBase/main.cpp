#include <iostream>
#include <fstream>

#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include <chrono>

#include <GL/glew.h>
#include <GL/freeglut.h>
#pragma comment(lib, "glew32.lib") 

#include "Skybox.h"


int SCREEN_WIDTH = 1280;
int SCREEN_HEIGHT = 720;

std::chrono::time_point<std::chrono::system_clock, std::chrono::milliseconds> programStartTime;

// Camera
glm::vec3 cameraPosition = glm::vec3(0, 0, 0);
glm::vec3 cameraForward = glm::vec3(0.0, 0.0, 15.0);

Skybox skybox;

void UpdateCamera()
{
}

// Initialization routine.
void setup(void)
{
	glClearColor(0.6, 0.8, 0.9, 0.0);

	glm::mat4 modelViewMat = glm::lookAt(cameraForward, glm::vec3(0), glm::vec3(0, 1, 0));
	glm::mat4 projectionMatrix = glm::perspective(glm::radians(60.0), (double)SCREEN_WIDTH / (double)SCREEN_HEIGHT, 0.1, 1000.0);

	skybox.InitialiseCubeMap();
	skybox.InitialiseSkybox();
	skybox.CreateShader("SkyboxVertexShader.glsl", "SkyboxFragmentShader.glsl");
	skybox.SetViewMatrix(modelViewMat);	
}

// Drawing routine.
void DisplayCallback(void)
{
	float curTime = ((std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now()) - programStartTime).count()) / 1000.0f;
	//std::cout << curTime << std::endl;
	
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);

	skybox.Bind();
	skybox.Draw();


	glutSwapBuffers();
}

// OpenGL window reshape routine.
void ResizeCallback(int w, int h)
{
	glViewport(0, 0, w, h);

	SCREEN_WIDTH = w;
	SCREEN_HEIGHT = h;

	glm::mat4 projectionMatrix = glm::perspective(glm::radians(60.0), (double)w / (double)h, 0.1, 1000.0);

	skybox.SetProjectionMatrix(projectionMatrix);

}

// Keyboard input processing routine.
void KeyInputCallback(unsigned char key, int x, int y)
{
	switch (key)
	{
	case 'w':
	{
		UpdateCamera();
	}break;
	case 's':
	{
		UpdateCamera();
	}break;
	case 'a':
	{
		UpdateCamera();
	}break;
	case 'd':
	{
		UpdateCamera();
	}break;
	case 'e':
	{
		UpdateCamera();
	}break;
	case 'q':
	{
		UpdateCamera();
	}break;
	case 27:
	{
		exit(0);
	}break;
	}
}

// Main routine.
int main(int argc, char* argv[])
{
	programStartTime = std::chrono::time_point_cast<std::chrono::milliseconds>(std::chrono::system_clock::now());
	glutInit(&argc, argv);

	// Set the version of OpenGL (4.2)
	glutInitContextVersion(4, 2);
	// The core profile excludes all discarded features
	glutInitContextProfile(GLUT_CORE_PROFILE);
	// Forward compatibility excludes features marked for deprecation ensuring compatability with future versions
	glutInitContextFlags(GLUT_FORWARD_COMPATIBLE);

	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA | GLUT_FULL_SCREEN);

	glutInitWindowSize(SCREEN_WIDTH, SCREEN_HEIGHT);
	glutInitWindowPosition(25, 25);
	glutCreateWindow("SkyBox");

	glutSetCursor(GLUT_CURSOR_NONE);

	// Set OpenGL to render in wireframe mode
	//glPolygonMode(GL_FRONT_AND_BACK, GL_LINE);

	glutDisplayFunc(DisplayCallback);
	glutReshapeFunc(ResizeCallback);
	glutKeyboardFunc(KeyInputCallback);
	glutIdleFunc(DisplayCallback);

	glewExperimental = GL_TRUE;
	glewInit();

	setup();

	glutMainLoop();
}
