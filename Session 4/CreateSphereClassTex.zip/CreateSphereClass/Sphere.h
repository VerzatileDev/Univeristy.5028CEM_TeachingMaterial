#pragma once
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <glm/gtc/matrix_inverse.hpp>
#include "vertex.h"

using namespace glm;

class Sphere
{
private:
	vec3 Position; //The Sphere position in 3D world
	VertexWtihNormal* sphereVerticesNor;  //Sphere vertices data with normals
	unsigned int* sphereIndices;          //Sphere triangle indices    

	int stacks; // nunber of stacks
	int slices; // number of slices
	float radius;

	void CreateSpherewithNormal(); //The function creates vertex data and normals 
public:
	Sphere();
	~Sphere();

	void SetPosition(vec3 newPos);  //set the 3D position of the sphere
	vec3 GetPosition(void);			//get the 3D position of the sphere    
	VertexWtihNormal* GetVerData(int&); //get vertex data and normals
	unsigned int* GetTriData(int&);		//get triangle index data
};

